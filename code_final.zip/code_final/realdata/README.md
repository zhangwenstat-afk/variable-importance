# 真实数据（第 7 节）

本目录是 `extra1029.tex` 第 7 节 Real data application 的代码、数据和结果。正文中的 Figure 6–9 和文中引用的数字都由这里的文件生成。估计量本身（求根、spacing 估计 g、方差公式）调用 `../conditional/conditional_mc/estimators.py`，没有另写一份。

## 与正文的对应

| 正文 | 数据集 | Y | Z | S |
|---|---|---|---|---|
| 7.1 NHANES，Figure 6、7 | NHANES 2011–2016（n = 5287） | OGTT 两小时血糖（mg/dL） | 空腹血糖；HbA1c；胰岛素 + 血脂 | 年龄、BMI |
| 7.2 Concrete strength，Figure 8(a)、9(a) | SonReb（n = 3226） | 抗压强度（MPa） | 超声波速 | 回弹值 |
| 7.2 Soil organic carbon，Figure 8(b)、9(b) | LUCAS 2015（n = 20383） | 有机碳（g/kg） | 光谱前 30 个主成分 | 年均气温 |
| 7.2 Warfarin dose，Figure 8(c)(d)、9(c) | IWPC，`simsl` 包（n = 1780） | 稳定周剂量（mg/week） | VKORC1；CYP2C9 | 体重（标准化） |

X 的具体变量、类别变量和 s₀ 网格见 `config.py`。

## 文件

```
config.py          四个数据集的 X、Z、S 网格、分折方式；带宽常数和划分次数
estimation.py      nuisance（GBM 均值 + 位置-尺度残差密度）、局部化估计、交叉拟合、holdout
run_estimation.py  运行一个数据集，写 results/<数据集>_a<alpha>_*.csv
make_figures.py    由 results/*_a0.1_final.csv 画 Figure 6–9
summarize.py       打印正文引用的拒绝范围、计数、SE 比值和下界
data/              下载与构建脚本，以及可公开的分析数据
data_restricted/   LUCAS 分析数据（许可不允许再分发，见其中的 README）
results/           正文使用的结果（alpha = 0.1）
figures/           make_figures.py 的输出，与 ../../figures/ 中的同名文件一致
```

`results/` 中每个数据集四个文件：`raw` 是每次划分、每个 (S, s₀, Z, 方法, c) 一行；`summary` 是 20 次划分的中位数汇总，SE² 取 median(SE_b² + (Δ̂_b − Δ̂)²)，`p0` 检验 H₀: Δ(s₀) ≤ 0；`final` 是正文使用的行（Semi c = 2，Conf c = 3，以及用 Semi 带宽的 Conf 作参照，加 marginal）；`holdout` 是用来核对带宽常数的样本外局部覆盖率。

## 设定

- α = 0.1；2 折交叉拟合重复 20 次（种子 20261019 + 划分编号），取中位数。
- m 用 `HistGradientBoostingRegressor`（500 次迭代，学习率 0.03，叶节点至少 40，L2 = 1，early stopping）。残差密度 ε = σ(V)U：训练折内再做 2 折得到残差，σ 由提升树拟合 |残差|，U 的密度用 Silverman 带宽的高斯 KDE。
- 带宽 h = c·√3·sd(S)·n^{-1/4}（Semi，c = 2）或 n^{-2/5}（Conf，c = 3）。
- 分折：NHANES、华法林随机；SonReb 按研究分层（研究编号在 X 中）；LUCAS 按 100 km 空间块。
- holdout 的划分（数据中的 `cycle` 列）：NHANES 为 2011–14 与 2015–16 周期；华法林为随机一半；SonReb 为各研究内随机一半；LUCAS 为空间块的一半。

## 重跑

```bash
source ../env.sh
python=/home/eason/anaconda3/bin/python
for d in nhanes sonreb warfarin lucas; do $python run_estimation.py $d --alpha 0.1 --jobs 10; done
$python make_figures.py ../../figures      # 或不加参数，写到 figures/
$python summarize.py
```

10 个进程下 NHANES 约 1 分钟，LUCAS 约 1.5 分钟，其余几十秒。已核对：用本目录代码重跑的 `*_final.csv` 与正文所用结果的差别在 1e-15 量级，四张图逐像素一致。

## 从原始数据重建分析数据

```bash
cd data
./download.sh raw                                   # NHANES、simsl、SonReb；LUCAS 需另行申请
python build_nhanes.py raw/nhanes .
Rscript simsl_to_csv.R raw/simsl/simsl/data/warfarin.RData raw/warfarin_raw.csv
python build_warfarin.py raw/warfarin_raw.csv .
python build_sonreb.py raw/sonreb .
# LUCAS：在 ESDAC 申请 LUCAS 2015 topsoil 数据，解压到 <lucas_dir>
python lucas_spectra.py <lucas_dir>/spectra/LUCAS2015_Soil_Spectra_EU28.zip ../data_restricted/lucas/spectra10nm.npz
python build_lucas.py <lucas_dir> ../data_restricted/lucas/spectra10nm.npz ../data_restricted/lucas
```

重建出的四个分析数据文件已与正文所用版本核对一致。样本筛选：NHANES 取 ≥ 20 岁、有 OGTT 两小时血糖和空腹血糖、BMI 不缺失、未诊断糖尿病且未用降糖药；SonReb 去掉研究内完全重复的记录；LUCAS 取有光谱、有机碳 ≤ 120 g/kg、有气候变量的样本。

## 数据来源与许可

- NHANES：CDC 公开数据。
- IWPC 华法林：R 包 `simsl` 0.2.1 中整理后的子集（GPL）；原始研究 IWPC (2009)。
- SonReb：Zenodo 10.5281/zenodo.15392443，CC BY 4.0。
- LUCAS 2015：ESDAC 个人许可，不得转让或再许可。使用时须致谢："The LUCAS 2015 topsoil dataset used in this work was made available by the European Commission through the European Soil Data Centre managed by the Joint Research Centre (JRC), http://esdac.jrc.ec.europa.eu/"。
