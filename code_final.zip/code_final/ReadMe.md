# 代码归档

这是 `extra1002.tex` 当前稿对应的代码。边际实验的入口和配置在 `marginal/`，条件实验在 `conditional/`，两边共用的库放在本目录的 `marginal_mc/`。条件实验的数据、讨厌参数和批处理直接调用这个库，所以没有把同一份代码再复制进两个子目录。

原始 Monte Carlo 结果没有放进本目录，仍在

`variable importance/code_new/marginal_mc_project/results/`

下面各表给出的目录名就是正文数字的来源。重跑时把 `--out` 指到新目录，不要写进这些已有目录。

## 目录

```
code_final/
  marginal_mc/          共用：数据、讨厌参数、边际估计、汇总
  marginal/             边际实验入口与正文配置
  conditional/
    conditional_mc/     条件实验估计与模拟
    configs/            正文表 3–8 的配置
    configs/historical/ 功效图和 acquisition 图当时的配置
  tests/                确定性检查，含 m_w 带宽锁定
  realdata/             第 7 节真实数据：代码、分析数据、结果与 Figure 6–9（见 realdata/README.md）
  env.sh                运行环境
```

`conditional_mc/kernel_g.py` 留在包里，正文各表没有使用它。

## 环境

```bash
source "/home/eason/variable importance/code_final/env.sh"
python=/home/eason/anaconda3/bin/python
```

`env.sh` 会带上这份代码的路径、`LD_PRELOAD`，并把 BLAS / OpenMP 线程数设为 1。依赖见 `requirements.txt`，核对过的版本见 `requirements-tested.txt`。

本地长任务用 100 个进程。先确认输出目录是空的新目录，再用 `--resume` 接着跑。

## 数字口径

种子：边际表和边际图是 `20260906`；正文表 3–8 以及 Figure 3、附录 Figure A3 是 `20261006`。

估计实验固定 `beta = 0.2`。检验实验把 `beta` 校准到 `Delta(s0) = 0.20`，原假设是单侧 `T = (Delta_hat - Delta0) / se`，`Delta0 = 0.20`。临界值用 `norm.ppf(0.95)` 和 `norm.ppf(0.975)`。

结果目录里的 csv 是原始尺度。写入 tex 时：

- 估计表的 Bias、SD、RMSE 用 `estimator_valid`；SE、Cover 用 `inference_valid`。乘 100 后，前四项保留两位小数，Cover 保留一位。
- 检验表的 Bias 用 `estimator_valid`；Size、Cover、区间长度、SD(T) 用 `inference_valid`。前四项乘 100 后保留一位，SD(T) 不乘并保留三位。
- `inference_valid` 要求 `se_x` 和 `se_w` 都为正。标准误非正的重复不进入 SE、Cover、Size、区间长度和 SD(T)。
- 乘 100 并四舍五入后正好是 0 的均值，表中写成 `0.0`。

`inference_valid` 是联合条件，所以只改 `m_w` 时，`zeta_x` 的点估计可以不变，它的 SE 和 Cover 仍可能变。

## 和 extra1002.tex 的对应

结果目录都相对于 `code_new/marginal_mc_project/results/`。配置相对于本归档。

### 边际

| 正文 | 配置 | 结果目录 |
| --- | --- | --- |
| `tab:learned-cv-zeta`，`fig:learned-cv-zeta-rmse` | `marginal/configs/learned_residual_cv_paper_a5_density_wide2_estimation_b02.json` | `learned_residual_cv_paper_a5_density_wide2_estimation_b02_r1000` |
| `tab:delta_calib` | `..._inference_d020.json`（只含 gap 0） | `..._inference_d020_size_r1000` |
| `fig:delta_power` | `..._inference_d020_power.json` | `..._inference_d020_power_r1000` |
| `tab:learned-cv-zeta-sym` | `..._estimation_b02_sym.json` | `..._estimation_b02_sym_r1000` |
| `tab:delta_calib-sym` | `..._inference_d020_sym.json` | `..._inference_d020_sym_r1000` |
| `tab:t4-learned-cv-zeta`，`fig:t4-learned-cv-zeta-rmse` | `..._t4_..._estimation_b02.json` | `..._t4_..._estimation_b02_r1000` |
| `tab:t4-delta-calib`，`fig:t4-delta-power` | `..._t4_..._inference_d020.json` | `..._t4_..._inference_d020_r1000` |
| `tab:sym-t4-learned-cv-zeta` | `..._t4_..._estimation_b02_sym.json` | `..._t4_..._estimation_b02_sym_r1000` |
| `tab:sym-t4-delta-calib` | `..._t4_..._inference_d020_sym.json` | `..._t4_..._inference_d020_sym_r1000` |

t4 检验配置含 gap `{-0.05, 0, 0.05, 0.1, 0.2}`。表用 gap 0，功效图用同一次运行的全部 gap。主文功效图是另一次运行，不含 gap 0。不要用带 `seed2026` 的边际目录，那个目录对不上正文。

### 条件：表 3–8，Figure 3，附录 Figure A3

这几项用当前代码：`c_semi = c_conf = 1.5`，`g_estimator = spacing`，`c_n` 因子 `0.75`，层 `learned_density_y20_w_hfhalf`，`w_hf_post_multiplier = 0.5`。带宽

`h_semi = 1.5 n^{-1/4}`，`h_conf = 1.5 n^{-2/5}`，

`c_n = min{0.05, 0.15 * 0.75 * (nh/2)^{-1/5}}`。

`m_w` 不读配置文件里的 `bandwidth_selection`。`conditional_mc/estimators.py` 在 `target == "w"` 时直接换成下面的网格；`m_x` 和其他位置仍用共享网格。

| 位置 | `m_w` 的 c | `m_w` 的 r |
| --- | --- | --- |
| `s0 = -0.5` | 0.1875, 0.25 | 32, 64 |
| `s0 = 0` | 0.5, 0.625 | 16, 32 |
| `s0 = 0.5` | 1.0, 1.5, 2.0, 2.5, 3.0 | 2, 4, 8, 12, 16 |

| 正文 | 配置 | 结果目录 |
| --- | --- | --- |
| `tab:cond-zeta-m05` | `conditional_est_..._s0m05_0_r1000.json` | `conditional_est_..._s0m05_0_r1000` 中 `s0 = -0.5` 的行 |
| `tab:cond-zeta-0` | `conditional_est_..._s00_wcv05_0625_r16_32_r1000.json` | 同名结果目录 |
| `tab:cond-zeta-p05` | 见下方重算脚本；从头重跑用 `conditional_est_..._s05_r1000.json` | `conditional_est_..._seonly_..._s05_r1000` |
| `tab:cond-delta-m05` | `conditional_infer_..._cn075_spacing_..._s0m05_r1000.json` | 见下方说明 |
| `tab:cond-delta-0` | `conditional_infer_..._s00_wcv05_0625_r16_32_r1000.json` | 同名结果目录 |
| `tab:cond-delta-p05` | 见下方重算脚本；从头重跑用 `conditional_infer_..._cn075_spacing_..._s05_r1000.json` | `conditional_infer_..._cn075_seonly_..._s05_r1000` |
| `fig:cond-zeta-rmse` | `conditional/plot_zeta_rmse.py` | 表 3、表 4、表 5 三个估计目录的 `zeta_x` |
| `fig:cond-zeta-w-rmse` | 同一个脚本 | 同样三个目录的 `zeta_w` |

表 3 那个已有目录里也有 `s0 = 0` 的行，那是旧的 `m_w` 网格，不要用来填表 4。表 4 以 `s00_wcv05_0625_r16_32` 那个目录为准。用当前代码重跑表 3 的配置时，`s0 = -0.5` 对应表 3，`s0 = 0` 对应表 4。

表 5 的点估计来自

`conditional_est_..._cn05_midroot_gslope_seed20261006_r1000`

和同名的 `n16000` 目录。标准误由 `conditional/recompute_est_spacing_se.py` 按 spacing、因子 0.75 重算，输出就是表中的 seonly 目录。`g` 的算法不进入点估计。

表 6 已保存的 `..._s0m05_wm05bw_r1000` 是因子 0.5 的标准误，和正文不一致。正文是同一批点估计在因子 0.75 下、并丢掉标准误非正的重复之后的汇总；那份汇总 csv 没有留在 `results/`。用上表里的 `cn075_spacing_..._s0m05` 配置从头重跑，得到的就是正文这张表。

表 8 的点估计来自因子 0.5 的三个推断目录：`n1k4k`、`n8000`、`n16000`。标准误由 `conditional/recompute_spacing_cn_se.py` 重算。不要用未跑完的 `..._cn075_midroot_..._s05_r1000`。

Figure 3 和 Figure A3 上排是 left，下排是 right，与现有 png 一致。

重算标准误时先 `source env.sh`，它把 `MC_PROJECT` 指到原来的结果目录：

```bash
"$python" conditional/recompute_est_spacing_se.py --out /tmp/cond_est_s05_cn075 --jobs 100
"$python" conditional/recompute_spacing_cn_se.py --out /tmp/cond_infer_s05_cn075 --jobs 100
"$python" conditional/plot_zeta_rmse.py --outdir /tmp/cond_figures
```

这两个重算脚本只读旧的原始结果，并写入 `--out`。

## 功效图和 acquisition 图

`fig:cond-delta-power`、`fig:cond-delta-power-n1000`、`fig:cond-delta-power-n4000` 来自 `results/conditional_infer_paper_gaps_r1000`。当时的配置在 `conditional/configs/historical/conditional_infer_paper_gaps_r1000.json`：种子 `20260906`，层 `learned_residual_cv_joint_r8_density_wide3`，`c_n` 因子 1，`n` 为 1000、4000、16000，`s0` 为 -0.5、0、0.5，gap 为 -0.05、0、0.05、0.1、0.2。

`fig:acquire-n4000` 与 `results/conditional_acquire_curve_n4000_11pt_r1000/figures/acquire_n4000.png` 是同一个文件。配置在 `historical/conditional_acquire_curve_n4000_11pt_r1000.json`：种子 `20260906`，`n = 4000`，`beta` 固定，位置从 -0.5 到 0.5、步长 0.1。

这两次运行早于现在的 `m_w` 锁定。用当前代码重跑这两份配置，会改动 `s0 = -0.5` 和 `s0 = 0`，不能逐点复现这两张图。表 3–8 和 Figure 3、Figure A3 不受这个限制。

## 运行

边际估计，输出写到新目录：

```bash
"$python" marginal/run_mc.py \
  --config marginal/configs/learned_residual_cv_paper_a5_density_wide2_estimation_b02.json \
  --out /tmp/marginal_est_b02 --jobs 100
```

条件表 4：

```bash
"$python" conditional/run_conditional.py \
  --config conditional/configs/conditional_est_y20_w_hfhalf_cn075_spacing_seed20261006_s00_wcv05_0625_r16_32_r1000.json \
  --out /tmp/cond_est_s00 --jobs 100
```

其他表把 `--config` 换成上一节对应的文件即可。汇总由运行结束时的 `summarize` 写出；已有原始 csv 时也可以用 `marginal/summarize_mc.py <输出目录>`。

带宽锁定的检查：

```bash
"$python" -m unittest tests.test_core.NuisanceTests.test_s0_mean_bandwidth_grid_is_local_and_does_not_mutate
```
